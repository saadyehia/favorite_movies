""" import fresh_tomatoes to displaying a static web page based on html/css
it's depend on take input a list of objects and output will produce each
movie in a box """
import fresh_tomatoes

# import webbrowser module to allow displaying web-based documents to users
import webbrowser


class Movie():
    """This Class Provides a way to store movie related information"""
    def __init__(self, movie_title, movie_image, movie_trailer_url):
        self.title = movie_title
        self.poster_image_url = movie_image
        self.trailer_youtube_url = movie_trailer_url

    def show_trailer(self):
        # using function 'open' to open an url in web page
        webbrowser.open(self.trailer_youtube_url)

""" now we start add movie details in our program like title, trailer
and poster """
# Hunger Games: Movie Title, Poster Image, Movie Trailer
hunger_games = Movie(
    "Hunger Games",
    "https://upload.wikimedia.org/wikipedia/en/4/42/HungerGamesPoster.jpg",
    "https://www.youtube.com/watch?v=FovFG3N_RSU"
    )
# Avatar: Movie Title, Poster Image, Movie Trailer
avatar = Movie(
    "Avatar",
    "https://upload.wikimedia.org/wikipedia/id/b/b0/Avatar-Teaser-Poster.jpg",
    "https://www.youtube.com/watch?v=5PSNL1qE6VY"
    )
# Toy Story: Movie Title, Poster Image, Movie Trailer
toy_story = Movie(
    "Toy Story",
    "https://upload.wikimedia.org/wikipedia/en/1/13/Toy_Story.jpg",
    "https://www.youtube.com/watch?v=vwyZH85NQC4"
    )
# School of Rock: Movie Title, Poster Image, Movie Trailer
school_of_rock = Movie(
    "School OF Rock",
    "https://upload.wikimedia.org/wikipedia/en/1/11/School_of_Rock_Poster.jpg",
    "https://www.youtube.com/watch?v=3PsUJFEBC74"
    )
# Ratatouille: Movie Title, Poster Image, Movie Trailer
ratatouille = Movie(
    "Ratatouille ",
    "https://upload.wikimedia.org/wikipedia/en/5/50/RatatouillePoster.jpg",
    "https://www.youtube.com/watch?v=c3sBBRxDAqk"
    )
# The Time Machine: Movie Title, Poster Image, Movie Trailer
the_time_machine = Movie(
    "The Time Machine",
    "https://upload.wikimedia.org/wikipedia/en/6/6f/Time_machine.jpg",
    "https://www.youtube.com/watch?v=-XMaEfJOGJg"
    )

""" movies is a class inside module 'fresh_tomatoes'
it's take an input as a  list of object"""
# Set The Movies that will be passed to the media file
movies = [
    hunger_games, avatar, toy_story, school_of_rock, ratatouille,
    the_time_machine
    ]
# Open The HTML File in a webbrowser via fresh_tomatoes.py file
fresh_tomatoes.open_movies_page(movies)
